# Donat Akian

Website landing page untuk toko Donat Akian, dibuat dengan Next.js dan siap dipublikasikan di Vercel.

## Menjalankan secara lokal
1. Install Node.js versi LTS.
2. Buka folder proyek di terminal.
3. Jalankan `npm install`.
4. Jalankan `npm run dev` lalu buka alamat yang tampil di terminal.

## Publikasi ke Vercel
1. Upload folder proyek ini ke repository GitHub.
2. Masuk ke https://vercel.com dan pilih **Add New → Project**.
3. Import repository GitHub tersebut.
4. Framework akan terdeteksi sebagai Next.js. Klik **Deploy**.

## Penting sebelum publikasi
Ganti nomor WhatsApp contoh `6281234567890` di `app/page.js` dengan nomor WhatsApp toko (format kode negara, tanpa tanda + atau spasi). Sesuaikan nama produk, harga, dan deskripsi dengan menu asli.
