import './globals.css';

export const metadata = {
  title: 'Donat Akian — Manisnya Bikin Hari Ceria',
  description: 'Donat lembut dengan topping favorit. Temukan rasa favoritmu di Donat Akian.',
};

export default function RootLayout({ children }) {
  return <html lang="id"><body>{children}</body></html>;
}
