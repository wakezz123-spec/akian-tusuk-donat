const products = [
  { name: 'Choco Crunch', detail: 'Cokelat lembut dengan taburan crunchy.', price: 'Rp8.000', emoji: '🍫', tone: 'choco', tag: 'Favorit' },
  { name: 'Strawberry Dream', detail: 'Glaze stroberi manis dengan warna ceria.', price: 'Rp8.000', emoji: '🍓', tone: 'berry', tag: 'Manis' },
  { name: 'Matcha Melt', detail: 'Aroma matcha yang khas dan creamy.', price: 'Rp9.000', emoji: '🍵', tone: 'matcha', tag: 'Spesial' },
  { name: 'Classic Sugar', detail: 'Donat klasik bertabur gula yang simpel.', price: 'Rp6.000', emoji: '✨', tone: 'sugar', tag: 'Klasik' },
];

function DonutArt({ tone = 'choco' }) {
  return <div className={`donut-art ${tone}`} aria-hidden="true"><div className="donut-hole" /><i /><b /><em /></div>;
}

export default function Home() {
  const waNumber = '6281234567890'; // Ganti dengan nomor WhatsApp toko
  return (
    <main>
      <nav className="nav wrap">
        <a className="brand" href="#home"><span className="brand-mark">D</span><span>donat<span className="brand-accent">akian.</span></span></a>
        <div className="nav-links"><a href="#menu">Menu</a><a href="#tentang">Tentang</a><a href="#kontak">Kontak</a></div>
        <a className="nav-cta" href={`https://wa.me/${waNumber}?text=${encodeURIComponent('Halo Donat Akian, saya ingin pesan donat.')}`} target="_blank" rel="noreferrer">Pesan sekarang ↗</a>
      </nav>

      <section className="hero wrap" id="home">
        <div className="hero-copy">
          <div className="eyebrow"><span /> FRESHLY MADE, HAPPILY SHARED</div>
          <h1>Satu gigitan,<br /><span>banyak</span> kebahagiaan.</h1>
          <p>Donat lembut, topping melimpah, dan rasa yang bikin hari jadi lebih istimewa. Temukan donat favoritmu di Donat Akian!</p>
          <div className="hero-actions"><a className="button primary" href="#menu">Lihat menu <span>↓</span></a><a className="text-link" href="#tentang">Kenalan dengan kami ↗</a></div>
          <div className="hero-note"><div className="avatar-stack"><span>🍩</span><span>💗</span><span>⭐</span></div><div><strong>Dibuat dengan sepenuh hati</strong><small>Untuk momen manis setiap hari</small></div></div>
        </div>
        <div className="hero-visual"><div className="sunburst" /><div className="hero-circle"><DonutArt tone="hero-donut" /></div><div className="float-card top">♡ <span>made with love</span></div><div className="float-card bottom"><strong>100%</strong><span>happy bites!</span></div><div className="sparkle s1">✳</div><div className="sparkle s2">✦</div></div>
      </section>

      <section className="ticker"><div>FRESH • SOFT • DELICIOUS • MADE FOR YOUR HAPPY DAYS • FRESH • SOFT • DELICIOUS • MADE FOR YOUR HAPPY DAYS •</div></section>

      <section className="menu-section wrap" id="menu">
        <div className="section-heading"><div><div className="eyebrow">PILIHAN YANG BIKIN HAPPY</div><h2>Menu <span>favorit</span></h2></div><p>Dari rasa klasik sampai topping kekinian,<br />semuanya siap jadi teman harimu.</p></div>
        <div className="product-grid">{products.map((p) => <article className="product-card" key={p.name}><div className={`product-visual ${p.tone}`}><span className="product-tag">{p.tag}</span><DonutArt tone={p.tone} /><span className="product-emoji">{p.emoji}</span></div><div className="product-info"><div><h3>{p.name}</h3><p>{p.detail}</p></div><div className="product-bottom"><strong>{p.price}</strong><a href={`https://wa.me/${waNumber}?text=${encodeURIComponent(`Halo Donat Akian, saya ingin pesan ${p.name}.`)}`} target="_blank" rel="noreferrer" aria-label={`Pesan ${p.name}`}>＋</a></div></div></article>)}</div>
        <p className="menu-footnote">*Harga dan ketersediaan menu dapat berubah. Hubungi kami untuk informasi terbaru.</p>
      </section>

      <section className="about-section" id="tentang"><div className="about-inner wrap"><div className="about-art"><div className="about-sticker">GOOD<br />MOOD<br /><span>FOOD!</span></div><div className="about-donut"><DonutArt tone="berry" /></div><span className="about-spark">✳</span></div><div className="about-copy"><div className="eyebrow">CERITA DONAT AKIAN</div><h2>Hal sederhana,<br />rasa yang <span>istimewa.</span></h2><p>Donat Akian hadir untuk menemani cerita dan momen spesialmu. Kami percaya kebahagiaan bisa dimulai dari hal sederhana—seperti donat lembut dengan topping favorit.</p><div className="values"><div><strong>♡</strong><span>Dibuat sepenuh hati</span></div><div><strong>✦</strong><span>Rasa yang bikin ceria</span></div><div><strong>☺</strong><span>Cocok untuk berbagi</span></div></div></div></div></section>

      <section className="cta-section wrap" id="kontak"><div className="cta-card"><div className="cta-deco">🍩</div><div className="eyebrow">YOUR HAPPY MOMENT STARTS HERE</div><h2>Sudah siap untuk<br /><span>yang manis-manis?</span></h2><p>Pesan donat favoritmu sekarang. Kami tunggu pesan manismu!</p><a className="button dark" href={`https://wa.me/${waNumber}?text=${encodeURIComponent('Halo Donat Akian, saya ingin melihat menu dan memesan donat.')}`} target="_blank" rel="noreferrer">Pesan lewat WhatsApp ↗</a></div></section>

      <footer className="footer wrap"><a className="brand" href="#home"><span className="brand-mark">D</span><span>donat<span className="brand-accent">akian.</span></span></a><p>Manisnya bikin hari ceria. ♡</p><span>© 2026 Donat Akian</span></footer>
    </main>
  );
}
